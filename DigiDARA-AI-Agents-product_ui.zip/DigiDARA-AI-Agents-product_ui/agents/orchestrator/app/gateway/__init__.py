"""Registry-resolved REST gateway."""
