import logging
import json
import os
from urllib.parse import urlparse

import httpx
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response

from app import config
from app.auth.security import decode_access_token
from app.auth import service as auth_service
from app.registry import service as registry_service

logger = logging.getLogger("orchestrator.gateway")
router = APIRouter(prefix="/gateway", tags=["gateway"])

# Registration itself has no way to know an agent's endpoint is legitimate
# beyond the shared secret, and the `action: "health"` branch below is
# intentionally unauthenticated — so without this check, anyone who can
# register an agent (or tamper with one's registered endpoint) can make this
# gateway proxy a request to an arbitrary host on the internal network.
# Every real agent endpoint is a loopback service on this box or an internal
# hostname; nothing else should ever be reachable through here.
ALLOWED_AGENT_HOSTS = {
    h.strip() for h in os.environ.get("ALLOWED_AGENT_HOSTS", "127.0.0.1,localhost").split(",") if h.strip()
}


@router.post("/agents/{agent_name}/invoke")
async def invoke_registered_agent(agent_name: str, request: Request) -> Response:
    """Forward JSON or multipart bodies only to a live registry endpoint."""
    agent = registry_service.resolve_healthy(agent_name)
    if agent is None:
        raise HTTPException(503, f"Agent {agent_name!r} is not registered or its heartbeat is stale.")

    host = urlparse(agent.endpoint).hostname
    if host not in ALLOWED_AGENT_HOSTS:
        logger.warning(
            "blocked gateway invoke to disallowed host: agent=%s endpoint=%s host=%s", agent_name, agent.endpoint, host
        )
        raise HTTPException(403, f"Registered endpoint for {agent_name!r} is not on an allowed host.")

    body = await request.body()
    envelope = None
    if request.headers.get("content-type", "").startswith("application/json"):
        try:
            envelope = json.loads(body)
        except (TypeError, ValueError):
            pass

    # Health polling carries no learner data and remains public. Every other
    # action must be tied to a valid DigiDARA login.
    is_health = isinstance(envelope, dict) and envelope.get("action") == "health"
    user_id = None
    if not is_health:
        authorization = request.headers.get("authorization", "")
        if not authorization.startswith("Bearer "):
            raise HTTPException(401, "Missing bearer token.")
        user_id = decode_access_token(authorization[7:])

    headers: dict[str, str] = {}
    if content_type := request.headers.get("content-type"):
        headers["content-type"] = content_type
    if accept := request.headers.get("accept"):
        headers["accept"] = accept
    if user_id:
        # Derived from the verified platform JWT, never from the JSON payload.
        headers["x-digidara-user-id"] = user_id

    if isinstance(envelope, dict):
        if envelope.get("action") == "ensure_session":
            user = auth_service.get_by_id(user_id)
            if user is None:
                raise HTTPException(401, "This account no longer exists.")
            payload = envelope.get("payload") if isinstance(envelope.get("payload"), dict) else {}
            # Identity bridges receive only server-verified profile fields;
            # browser-supplied identity values are never forwarded.
            payload.update({"user_id": user.id, "name": user.name, "email": user.email, "mobile": user.mobile or ""})
            envelope["payload"] = payload
            body = json.dumps(envelope).encode("utf-8")

    try:
        async with httpx.AsyncClient(timeout=config.AGENT_CALL_TIMEOUT_SECONDS) as client:
            upstream = await client.post(agent.endpoint, content=body, headers=headers)
    except httpx.HTTPError as exc:
        logger.exception("gateway call failed: agent=%s endpoint=%s", agent_name, agent.endpoint)
        raise HTTPException(502, f"Registered agent {agent_name!r} could not be reached.") from exc

    response_headers: dict[str, str] = {}
    if upstream_content_type := upstream.headers.get("content-type"):
        response_headers["content-type"] = upstream_content_type
    if disposition := upstream.headers.get("content-disposition"):
        response_headers["content-disposition"] = disposition
    return Response(content=upstream.content, status_code=upstream.status_code, headers=response_headers)
