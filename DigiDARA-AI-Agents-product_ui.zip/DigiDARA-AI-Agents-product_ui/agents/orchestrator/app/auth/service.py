from app.db import get_session
from app.models import User


def get_by_email(email: str) -> User | None:
    session = get_session()
    try:
        return session.query(User).filter_by(email=email).first()
    finally:
        session.close()


def get_by_id(user_id: str) -> User | None:
    session = get_session()
    try:
        return session.get(User, user_id)
    finally:
        session.close()


def get_by_google_id(google_id: str) -> User | None:
    session = get_session()
    try:
        return session.query(User).filter_by(google_id=google_id).first()
    finally:
        session.close()


def create_user(name: str, email: str, mobile: str | None, password_hash: str) -> User:
    session = get_session()
    try:
        user = User(name=name, email=email, mobile=mobile, password_hash=password_hash)
        session.add(user)
        session.commit()
        session.refresh(user)
        return user
    finally:
        session.close()


def create_google_user(name: str, email: str, google_id: str) -> User:
    """No password_hash — this account can only ever sign in via Google."""
    session = get_session()
    try:
        user = User(name=name, email=email, google_id=google_id)
        session.add(user)
        session.commit()
        session.refresh(user)
        return user
    finally:
        session.close()


def link_google_id(user_id: str, google_id: str) -> User:
    """A password account signing in with Google for the first time under
    the same email — attach the Google identity rather than creating a
    second account."""
    session = get_session()
    try:
        user = session.get(User, user_id)
        user.google_id = google_id
        session.commit()
        session.refresh(user)
        return user
    finally:
        session.close()
