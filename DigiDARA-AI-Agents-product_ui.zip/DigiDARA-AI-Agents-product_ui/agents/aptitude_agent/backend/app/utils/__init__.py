"""Shared backend utilities."""

